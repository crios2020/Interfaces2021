use negocioWeb;
select * from direcciones;
select * from clientes;


