var x=2
x="hola"

//Comentarios
/* bloque de comentarios */

console.log("Imprimir en consola")
//document.writeln("Hola Mundo JS");
//alert("Hola Mundo JS")

document.getElementById("div1").innerHTML="<p>Hola Mundo JS</p>";
document.getElementById("div2").innerHTML="<p>Centro 8</p>";
